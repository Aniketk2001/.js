const swaggerJsdoc = require('swagger-jsdoc');
const swaggerUi = require('swagger-ui-express');

const adminOptions = {
    definition: {
        openapi: '3.0.0',

        info: {
            title: 'Arthomed',
            version: '1.0.0',
            description: 'Arthomed APIs',
        },
    },
    securityDefinitions: {
        bearerAuth: {
            type: 'apiKey',
            name: 'Authorization',
            scheme: 'bearer',
            in: 'header',
        },
    },
    apis: ['./src/routes/*.js'],
};



function userOption(option) {

    spec = swaggerJsdoc(adminOptions);
    return swaggerUi.setup(spec);
}

module.exports = { userOption };

