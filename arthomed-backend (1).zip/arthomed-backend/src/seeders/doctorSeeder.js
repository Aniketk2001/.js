const User = require('../models/User');
const connectDB = require('../config/database');
require('dotenv').config();

const seedDoctor = async () => {
  try {
    await connectDB();

    const existing = await User.findOne({ mobileNumber: '+917020674000', role: 'doctor' });

    if (existing) {
      console.log('Doctor already exists.');
      return;
    }

    const newDoctor = new User({
      name: 'Dr. Raghu Nagaraj',
      mobileNumber: '+917020674000',
      email: 'defaultdoctor@example.com',
      role: 'doctor',
      isVerified: true,
      isActive: true,
      profile: {
        gender: 'male',
        dateOfBirth: new Date('1980-01-01'),
        address: 'Bangalore',
      },
      doctorInfo: {
        specialization: 'Cardiologist',
        education: 'MBBS, MD',
        experience: '15 years',
        licenseNumber: 'DOC123456',
        bio: 'Experienced general physician available for consultations.',
        workingHours: '10:00 AM - 6:00 PM',
        ratings: 0,
        reviews: 0
      }
    });

    await newDoctor.save();
    console.log('Default doctor seeded successfully');
  } catch (error) {
    console.error('Error seeding doctor:', error.message);
  }
};

seedDoctor();
