const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const saveBase64Images = async (photos, folderName) => {
  const folderPath = path.join(__dirname, '../uploads', folderName);
  if (!fs.existsSync(folderPath)) {
    fs.mkdirSync(folderPath, { recursive: true });
  }

  const savedUrls = [];

  for (const base64 of photos) {
    const matches = base64.match(/^data:(.+);base64,(.+)$/);
    if (!matches) continue;

    const ext = matches[1].split('/')[1];
    const buffer = Buffer.from(matches[2], 'base64');
    const filename = `${uuidv4()}.${ext}`;
    const filepath = path.join(folderPath, filename);

    fs.writeFileSync(filepath, buffer);

    // Construct the full URL
    const fullUrl = `${process.env.BASE_URL || 'http://localhost:5000'}/uploads/${folderName}/${filename}`;
    savedUrls.push(fullUrl);
  }

  return savedUrls;
};

module.exports = saveBase64Images;