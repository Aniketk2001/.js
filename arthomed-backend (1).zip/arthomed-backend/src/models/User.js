const mongoose = require('mongoose');
const Counter = require('./Counter');
require('dotenv').config(); 

const profileSchema = new mongoose.Schema({
  gender: {
    type: String,
    enum: ['male', 'female', 'other'],
    default: 'other',
  },
  dateOfBirth: Date,
  photo: String,
  address: String,
}, { _id: false });

const doctorInfoSchema = new mongoose.Schema({
  specialization: String,
  education: String,
  experience: String,
  licenseNumber: String,
  bio: String,
  workingHours: { type: String },
  ratings: { type: Number, default: 0, min: 0, max: 5 },
  reviews: { type: Number, default: 0, min: 0, max: 5 }
}, { _id: false });

const patientInfoSchema = new mongoose.Schema({
  bloodGroup: String,
  allergies: [String],
  medicalHistory: [String],
}, { _id: false });

const userSchema = new mongoose.Schema({
  _id: {
    type: String, // Custom ID
  },
  name: {
    type: String,
    required: true,
    trim: true,
  },
  email: {
    type: String,
    lowercase: true,
    unique: true,
    sparse: true,
    trim: true,
  },
  mobileNumber: {
    type: String,
    required: true,
    unique: true,
  },
  role: {
    type: String,
    enum: ['admin', 'doctor', 'patient', 'receptionist'],
    default: 'patient',
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  profile: profileSchema,
  doctorInfo: doctorInfoSchema,
  patientInfo: patientInfoSchema,
}, { timestamps: true });

// Pre-save hook to generate custom _id
userSchema.pre('save', async function (next) {
  const user = this;
  if (user.isNew && !user._id) {
    const prefix = process.env.USER_ID_PREFIX || 'ARTH';

    const counter = await Counter.findOneAndUpdate(
      { id: 'userId' },
      { $inc: { seq: 1 } },
      { new: true, upsert: true }
    );

    user._id = `${prefix}${String(counter.seq).padStart(3, '0')}`; // e.g., ARTH001
  }
  next();
});

module.exports = mongoose.model('User', userSchema);
