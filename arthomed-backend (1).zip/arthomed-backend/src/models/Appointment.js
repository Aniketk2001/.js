const mongoose = require('mongoose');
const Counter = require('./Counter');
require('dotenv').config();

const appointmentSchema = new mongoose.Schema({
  _id: { type: String }, // Custom appointment ID

  patient: {
    patientId: { type: String, ref: 'User' },
    name: String,
    mobile: String,
    purpose: String,
    photos: [String],
  },
  doctor: { type: String, ref: 'User' },
  date: String,
  time: String,
  status: { type: String, enum: ['upcoming', 'completed', 'canceled'], default: 'upcoming' },
  payment: {
    method: { type: String, enum: ['online', 'cash'] },
    paid: Boolean,
    transactionId: String
  },
  createdAt: { type: Date, default: Date.now }
});

// Pre-save hook for generating custom _id
appointmentSchema.pre('save', async function (next) {
  if (this.isNew && !this._id) {
    const prefix = process.env.APPOINTMENT_ID_PREFIX || 'APT';

    const counter = await Counter.findOneAndUpdate(
      { id: 'appointmentId' },
      { $inc: { seq: 1 } },
      { new: true, upsert: true }
    );

    this._id = `${prefix}${String(counter.seq).padStart(4, '0')}`; // e.g., APT0001
  }
  next();
});

module.exports = mongoose.model('Appointment', appointmentSchema);
