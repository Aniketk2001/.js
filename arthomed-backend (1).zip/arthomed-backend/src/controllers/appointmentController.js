const Appointment = require('../models/Appointment');
const User = require('../models/User');
const saveBase64Images = require('../utils/saveBase64Images');
const moment = require('moment');

const parseTime = (timeStr, dateStr) => moment(`${dateStr} ${timeStr}`, 'DD/MM/YYYY hh:mm A');


const bookAppointment = async (req, res) => {
  try {
    const { name, mobile, purpose, photos = [], doctorId, date, time, paymentMethod } = req.body;
    const doctorUser = await User.findOne({ role: 'doctor' });

    const id = req.user?.id || req.session?.user?._id;

    if (!doctorUser) {
      return res.status(404).json({ message: 'No doctor found in the system' });
    }
    const existingAppointment = await Appointment.findOne({
      doctor: doctorUser._id,
      date,
      time,
      status: { $ne: 'cancelled' } 
    });

    if (existingAppointment) {
      return res.status(400).json({
        message: 'An appointment already exists at this time for the doctor'
      });
    }

    const photoPaths = await saveBase64Images(photos, 'patient');

    const appointment = new Appointment({
      patient: { name, mobile, purpose, photos: photoPaths, patientId: id },
      doctor: doctorUser._id,
      date,
      time,
      payment: { method: paymentMethod, paid: false }
    });

    await appointment.save();

    res.status(201).json({
      message: "Appointment booked successfully",
      appointment:{...appointment,doctor:doctorUser}
    });
  } catch (error) {
    res.status(500).json({ message: "Booking failed", error: error.message });
  }
};



const getBookedSlotsByDate =async (req, res) => {
  try {
    const { date } = req.query;
console.log(date,"date");

    if (!date) {
      return res.status(400).json({ message: "Date is required in query parameters" });
    }


    const doctor = await User.findOne({ role: 'doctor' });
    if (!doctor) return res.status(404).json({ message: "Doctor not found" });

    const appointments = await Appointment.find({
      doctor: doctor._id,
      date: date,
    });
console.log(appointments,"appointments");

    const bookedSlots = appointments.map(app => app.time);

    res.status(200).json({ date, bookedSlots });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch booked slots", error: error.message });
  }
};


const getDoctorSlotsByDate = async (req, res) => {
  try {
    const { doctorId, date } = req.query;
   

    // if (!doctorId) {
    //   return res.status(400).json({ message: 'doctorId is required' });
    // }

    if (!date || !moment(date, 'DD/MM/YYYY', true).isValid()) {
      return res.status(400).json({ message: 'Invalid or missing date (use DD/MM/YYYY)' });
    }

    // const doctor = await User.findById(doctorId);
     const doctor = await User.findOne({ role: 'doctor' });
    if (!doctor || doctor.role !== 'doctor') {
      return res.status(404).json({ message: 'Doctor not found' });
    }

    const workingHours = doctor.doctorInfo?.workingHours || '10:00 AM - 6:00 PM';
    const [startStr, endStr] = workingHours.split(' - ');

    const startTime = parseTime(startStr, date);
    const endTime = parseTime(endStr, date);
    const slotDuration = 60; // 1 hour slots
    const allSlots = [];

    const current = startTime.clone();
    while (current < endTime) {
      allSlots.push(current.format('hh:mm A'));
      current.add(slotDuration, 'minutes');
    }

    // Get appointments (exclude canceled)
    const bookedAppointments = await Appointment.find({
      doctor: doctor._id,
      date: date,
      status: { $ne: 'canceled' }
    });
    const bookedTimes = bookedAppointments.map(app => app.time);

    const Slots = allSlots.map(time => ({
      time,
      available: !bookedTimes.includes(time)
    }));

    res.json({ date, Slots });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching doctor slots', error: err.message });
  }
};


const getMyAppointments = async (req, res) => {
  try {
    const { _id: userId, role } = req.user || req.session?.user;
    const { status } = req.query;

    const filter = {};

    if (role === 'patient') {
      filter['patient.patientId'] = userId;
    } else if (role === 'doctor') {
      filter.doctor = userId;
    } else {
      return res.status(403).json({ success: false, message: 'Access denied' });
    }

    if (status) {
      filter.status = status;
    }

    const appointments = await Appointment.find(filter)
      .populate('doctor', 'name mobileNumber profile doctorInfo') // only return needed fields
      .populate('patient.patientId', 'name mobileNumber profile')
      .sort({ date: -1, time: -1 });

    res.status(200).json({
      success: true,
      count: appointments.length,
      data: appointments
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to fetch appointments',
      error: error.message
    });
  }
};


const getAllBookedDates = async (req, res) => {
  try {
    // Get appointments with status 'upcoming' or 'completed'
    const appointments = await Appointment.find({
      status: { $in: ['upcoming', 'completed'] }
    }).select('date -_id').distinct('date');;
    const uniqueDates = Array.from(appointments).sort();

    res.status(200).json({
      success: true,
      count: uniqueDates.length,
      dates: uniqueDates
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Error fetching booked dates',
      error: error.message
    });
  }
};
















module.exports = {
  bookAppointment,
  getMyAppointments,
  getBookedSlotsByDate,
  getDoctorSlotsByDate,
  getAllBookedDates
};
