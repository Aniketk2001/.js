const User = require('../models/User');
const OTP = require('../models/Otp');
const twilio = require('twilio');
const jwt = require('jsonwebtoken');
const TokenBlacklist = require('../models/TokenBlacklist');

const fs = require('fs');
const path = require('path');

const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

/**
 * @desc    Verify OTP
 * @route   POST /api/auth/verify-otp
 * @access  Public
 */

const verifyOTPController = async (req, res) => {
  try {
    const { mobileNumber, otp } = req.body;

    if (!mobileNumber || !otp) {
      return res.status(400).json({ success: false, message: 'Mobile number and OTP are required.' });
    }

    const formattedMobile = mobileNumber.trim();

    // Find OTP in DB
    const otpRecord = await OTP.findOne({ mobileNumber: formattedMobile }).sort({ createdAt: -1 });

    if (!otpRecord) {
      return res.status(400).json({ success: false, message: 'No OTP found or expired.' });
    }

    if (otpRecord.otp !== otp) {
      return res.status(400).json({ success: false, message: 'Invalid OTP.' });
    }

    if (new Date() > otpRecord.expiresAt) {
      await OTP.deleteMany({ mobileNumber: formattedMobile });
      return res.status(400).json({ success: false, message: 'OTP has expired. Please request a new one.' });
    }

    // Update user
    const user = await User.findOne({ mobileNumber: formattedMobile });
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    user.isVerified = true;
    await user.save();

    // Delete OTPs for this mobile
    await OTP.deleteMany({ mobileNumber: formattedMobile });

    // Generate JWT
    const token = jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
      expiresIn: '365d',
    });


    return res.status(200).json({
      success: true,
      message: 'OTP verified successfully.',
      token,
      role: user.role,
      userId: user._id,
    });

  } catch (error) {
    console.error('OTP verification error:', error);
    return res.status(500).json({ success: false, message: 'OTP verification failed.', error: error.message });
  }
};
/**
 * @desc    Login with mobile number (send OTP)
 * @route   POST /api/auth/login
 * @access  Public
 */

const loginController = async (req, res) => {
  try {

    const { mobileNumber } = req.body;

    if (!mobileNumber) {
      return res.status(400).json({ success: false, message: 'Mobile number is required.' });
    }

    const formattedMobile = mobileNumber.trim();
    const user = await User.findOne({ mobileNumber: formattedMobile });

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found. Please register first.' });
    }

    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    // Save OTP to DB
    await OTP.create({
      mobileNumber: formattedMobile,
      otp,
      expiresAt,
    });

    // Send OTP via Twilio
    // await client.messages.create({
    //   body: `Your login OTP is: ${otp}`,
    //   from: process.env.TWILIO_PHONE_NUMBER,
    //   to: '+91' + formattedMobile,
    // });

    return res.status(200).json({
      success: true,
      message: 'OTP sent to registered mobile number.',
      userId: user._id,
      mobileNumber: formattedMobile,
    });

  } catch (error) {
    console.error('Login OTP error:', error);
    return res.status(500).json({
      success: false,
      message: 'Something went wrong while sending OTP.',
      error: error.message,
    });
  }
};
/**
 * @desc    Register new user (create user and send OTP)
 * @route   POST /api/auth/register
 * @access  Public
 */


const registerController = async (req, res) => {
  try {
    const { mobileNumber, name, email, gender, dob, role = 'patient' } = req.body;

    if (!mobileNumber || !name) {
      return res.status(400).json({ success: false, message: 'Mobile number and name are required.' });
    }

    const formattedMobile = mobileNumber.trim();

    const existingUser = await User.findOne({ mobileNumber: formattedMobile });
    if (existingUser) {
      return res.status(409).json({ success: false, message: 'Mobile number already registered. Please login.' });
    }

    const userData = {
      mobileNumber: formattedMobile,
      name: name.trim(),
      email: email?.trim(),
      role,
      isVerified: false,
      isActive: true,
      profile: {},
    };

    if (gender) userData.profile.gender = gender;
    if (dob) userData.profile.dateOfBirth = dob;

    const user = new User(userData);
    await user.save();

    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Save OTP to DB
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes from now
    await OTP.create({
      mobileNumber: formattedMobile,
      otp,
      expiresAt,
    });

    // Send OTP via Twilio
    // await client.messages.create({
    //   body: `Your verification OTP is: ${otp}`,
    //   from: process.env.TWILIO_PHONE_NUMBER,
    //   to: formattedMobile,
    // });

    return res.status(201).json({
      success: true,
      message: 'User registered. OTP sent to mobile number.',
      userId: user._id,
      mobileNumber: formattedMobile,
    });

  } catch (error) {
    console.error('Registration error:', error);
    return res.status(500).json({ success: false, message: 'Registration failed.', error: error.message });
  }
};

/**
 * @desc    Get current authenticated user
 * @route   GET /api/auth/user
 * @access  Private
 */
const getAuthUserController = async (req, res) => {
  try {
    const id = req.user?.id || req.session?.user?._id;
    const user = await User.findById(id);

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    const baseUrl = `${req.protocol}://${req.get('host')}`;

    const userObj = user.toObject();

    // If photo exists, add full URL
    if (userObj.profile?.photo) {
      userObj.profile.photo = baseUrl + userObj.profile.photo;
    }

    res.status(200).json({
      success: true,
      user: userObj,
    });
  } catch (error) {
    console.error('Get auth user error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch user',
      error: error.message,
    });
  }
};


/**
 * @desc    Logout user
 * @route   POST /api/auth/logout
 * @access  Private (Client should just delete token)
 */
const logoutController = async (req, res) => {
  try {
    const token = req.headers.authorization.split(' ')[1];
    const decoded = jwt.decode(token);

    const expiresAt = new Date(decoded.exp * 1000); // convert exp to Date

    await TokenBlacklist.create({ token, expiresAt });

    return res.status(200).json({
      success: true,
      message: 'Logout successful. Token blacklisted.',
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Logout failed.',
      error: error.message,
    });
  }
};



const updateAuthUserController = async (req, res) => {
  try {
    const userId = req.user?.id || req.session?.user?._id;

    if (!userId) {
      return res.status(401).json({ success: false, message: 'Unauthorized' });
    }

    const {
      name,
      email,
      gender,
      dateOfBirth,
      photo, // base64 string
      doctorInfo,
      patientInfo,
    } = req.body;

    const updateData = {};

    if (name) updateData.name = name;
    if (email) updateData.email = email;

    // Handle profile
    updateData.profile = {};
    if (gender) updateData.profile.gender = gender;
    if (dateOfBirth) updateData.profile.dateOfBirth = dateOfBirth;

    // ✅ Handle base64 photo
    if (photo && photo.startsWith('data:image')) {
      const matches = photo.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      if (!matches) {
        return res.status(400).json({ success: false, message: 'Invalid image format.' });
      }

      const ext = matches[1].split('/')[1];
      const base64Data = matches[2];
      const fileName = `user_${userId}_${Date.now()}.${ext}`;
      const filePath = path.join(__dirname, '../uploads', fileName);
      const publicPath = `/uploads/${fileName}`; // adjust if needed

      fs.writeFileSync(filePath, Buffer.from(base64Data, 'base64'));
      updateData.profile.photo = publicPath;
    }

    // Role-specific updates
    if (doctorInfo) updateData.doctorInfo = doctorInfo;
    if (patientInfo) updateData.patientInfo = patientInfo;

    const updatedUser = await User.findByIdAndUpdate(userId, updateData, { new: true });

    if (!updatedUser) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    res.status(200).json({
      success: true,
      message: 'User profile updated successfully',
      user: updatedUser,
    });
  } catch (error) {
    console.error('Update user error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update user profile',
      error: error.message,
    });
  }
};





module.exports = {
  verifyOTPController,
  loginController,
  registerController,
  getAuthUserController,
  logoutController,
  updateAuthUserController
};
