const express = require('express');
const {
  bookAppointment,
  getMyAppointments,
  getBookedSlotsByDate,
  getDoctorSlotsByDate,
  getAllBookedDates,
} = require('../controllers/appointmentController');

const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();


/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 */


/**
 * @swagger
 * /api/appointments/book:
 *   post:
 *     security:
 *       - bearerAuth: []   # 🔑 Require JWT here
 *     tags:
 *       - Appointments
 *     summary: Book a new appointment
 *     description: Allows booking an appointment for a patient. Automatically assigns the default doctor (only one doctor in the system). Accepts up to 4 base64-encoded images.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - mobile
 *               - purpose
 *               - date
 *               - time
 *               - paymentMethod
 *             properties:
 *               name:
 *                 type: string
 *               mobile:
 *                 type: string
 *               purpose:
 *                 type: string
 *               date:
 *                 type: string
 *               time:
 *                 type: string
 *               paymentMethod:
 *                 type: string
 *               photos:
 *                 type: array
 *                 items:
 *                   type: string
 *     responses:
 *       201:
 *         description: Appointment booked successfully
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Server error
 */


router.post(
  '/book',
  authMiddleware,
  bookAppointment
);


/**
 * @swagger
 * /api/appointments/booked-slots:
 *   get:
 *     tags:
 *       - Appointments
 *     summary: Get booked time slots for a specific date
 *     description: Returns all booked time slots for the default doctor on the provided date (in DD/MM/YYYY format).
 *     parameters:
 *       - in: query
 *         name: date
 *         schema:
 *           type: string
 *           example: "25/07/2025"
 *         required: true
 *         description: Date in DD/MM/YYYY format
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of booked slots for the given date
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 date:
 *                   type: string
 *                   example: "25/07/2025"
 *                 bookedSlots:
 *                   type: array
 *                   items:
 *                     type: string
 *                   example: ["10:00 AM", "11:30 AM"]
 *       400:
 *         description: Missing or invalid date
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Date is required in query parameters"
 *       500:
 *         description: Failed to fetch booked slots
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Failed to fetch booked slots"
 *                 error:
 *                   type: string
 */

router.get('/booked-slots',authMiddleware, getBookedSlotsByDate);

/**
 * @swagger
 * /api/appointments/slots:
 *   get:
 *     tags:
 *       - Appointments
 *     summary: Get available slots for a doctor on a given date
 *     parameters:
 *       - in: query
 *         name: doctorId
 *         required: true
 *         schema:
 *           type: string
 *         description: ID of the doctor
 *       - in: query
 *         name: date
 *         required: true
 *         schema:
 *           type: string
 *           example: "25/07/2025"
 *         description: Date in DD/MM/YYYY format
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of time slots with availability
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 date:
 *                   type: string
 *                 Slots:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       time:
 *                         type: string
 *                       available:
 *                         type: boolean
 *       400:
 *         description: Bad request (missing doctorId or invalid date)
 *       404:
 *         description: Doctor not found
 *       500:
 *         description: Internal server error
 */

router.get('/slots',authMiddleware, getDoctorSlotsByDate);


/**
 * @swagger
 * /api/appointments/my-appointments:
 *   get:
 *     summary: Get appointments for logged-in doctor or patient
 *     tags:
 *       - Appointments
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [upcoming, completed, cancelled]
 *         description: Filter appointments by status
 *     responses:
 *       200:
 *         description: List of appointments
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden (wrong role)
 *       500:
 *         description: Server error
 */


router.get(
  '/my-appointments',
   authMiddleware,
  getMyAppointments
);

/**
 * @swagger
 * /api/appointments/booked-dates:
 *   get:
 *     summary: Get all unique booked appointment dates (upcoming and completed)
 *     tags:
 *       - Appointments
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: List of booked dates
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 count:
 *                   type: integer
 *                   example: 5
 *                 dates:
 *                   type: array
 *                   items:
 *                     type: string
 *                     example: "25/07/2025"
 *       401:
 *         description: Unauthorized (missing or invalid token)
 *       500:
 *         description: Internal server error
 */

router.get('/booked-dates',authMiddleware, getAllBookedDates);


/**
 * @swagger
 * components:
 *   schemas:
 *     Appointment:
 *       type: object
 *       properties:
 *         _id:
 *           type: string
 *           example: "64a8917b3c1d8f0012ab4e0a"
 *         patient:
 *           type: object
 *           properties:
 *             name:
 *               type: string
 *               example: "Ravi Kumar"
 *             mobile:
 *               type: string
 *               example: "9876543210"
 *             purpose:
 *               type: string
 *               example: "General Checkup"
 *             photos:
 *               type: array
 *               items:
 *                 type: string
 *               example: ["/uploads/image1.jpg", "/uploads/image2.jpg"]
 *         doctor:
 *           type: string
 *           example: "64a8917b3c1d8f0012ab4d09"
 *         date:
 *           type: string
 *           example: "2025-08-01"
 *         time:
 *           type: string
 *           example: "10:30 AM"
 *         status:
 *           type: string
 *           enum: [upcoming, completed, canceled]
 *           example: "upcoming"
 *         payment:
 *           type: object
 *           properties:
 *             method:
 *               type: string
 *               enum: [online, cash]
 *               example: "cash"
 *             paid:
 *               type: boolean
 *               example: false
 *             transactionId:
 *               type: string
 *               example: null
 *         createdAt:
 *           type: string
 *           format: date-time
 *           example: "2025-07-26T10:00:00.000Z"
 */

module.exports = router;
