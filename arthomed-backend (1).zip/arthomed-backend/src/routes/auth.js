const express = require('express');
const {
  verifyOTPController,
  loginController,
  registerController,
  getAuthUserController,
  logoutController,
  updateAuthUserController
} = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();


/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 */




/**
 * @swagger
 * /api/auth/register:
 *   post:
 *     tags:
 *       - Authentication
 *     summary: Register a new user
 *     description: Registers a user by mobile number and sends an OTP for verification.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               mobileNumber:
 *                 type: string
 *                 example: "9876543210"
 *               name:
 *                 type: string
 *                 example: "John Doe"
 *               email:
 *                 type: string
 *                 format: email
 *                 example: "john@example.com"
 *               gender:
 *                 type: string
 *                 enum: [male, female, other]
 *                 example: "male"
 *               dob:
 *                 type: string
 *                 format: date
 *                 example: "01/12/2000"
 *             required:
 *               - mobileNumber
 *               - name
 *     responses:
 *       201:
 *         description: User registered and OTP sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: User registered. OTP sent to mobile number.
 *                 userId:
 *                   type: string
 *                   example: "64b77f5c9fae2b6a0cc21b80"
 *                 mobileNumber:
 *                   type: string
 *                   example: "9876543210"
 *       400:
 *         description: Mobile number or name missing
 *       409:
 *         description: Mobile number already registered
 *       500:
 *         description: Internal server error
 */

router.post(
  '/register',
  registerController
);


/**
 * @swagger
 * /api/auth/verify-otp:
 *   post:
 *     tags:
 *       - Authentication
 *     summary: Verify OTP
 *     description: Verifies the OTP for a given mobile number and returns a JWT token if successful.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               mobileNumber:
 *                 type: string
 *                 example: "9876543210"
 *               otp:
 *                 type: string
 *                 example: "123456"
 *             required:
 *               - mobileNumber
 *               - otp
 *     responses:
 *       200:
 *         description: OTP verified successfully and token generated
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: OTP verified successfully.
 *                 token:
 *                   type: string
 *                   example: "eyJhbGciOiJIUzI1NiIsInR5cCI6..."
 *                 role:
 *                   type: string
 *                   example: "patient"
 *                 userId:
 *                   type: string
 *                   example: "64b77f5c9fae2b6a0cc21b80"
 *       400:
 *         description: Missing fields, invalid OTP, or expired OTP
 *       404:
 *         description: User not found
 *       500:
 *         description: Internal server error
 */


router.post(
  '/verify-otp',
  verifyOTPController
);

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     tags:
 *       - Authentication
 *     summary: Login with mobile number
 *     description: Sends an OTP to the registered mobile number for login.
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               mobileNumber:
 *                 type: string
 *                 example: "9876543210"
 *             required:
 *               - mobileNumber
 *     responses:
 *       200:
 *         description: OTP sent successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: OTP sent to registered mobile number.
 *                 userId:
 *                   type: string
 *                   example: "64b77f5c9fae2b6a0cc21b80"
 *                 mobileNumber:
 *                   type: string
 *                   example: "9876543210"
 *       400:
 *         description: Mobile number is missing
 *       404:
 *         description: User not found
 *       500:
 *         description: Internal server error
 */

router.post(
  '/login',
  loginController
);

/**
 * @swagger
 * /api/auth/user:
 *   get:
 *     tags:
 *       - Authentication
 *     summary: Get authenticated user
 *     description: Returns details of the currently authenticated user based on JWT token.
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Authenticated user retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 user:
 *                   type: object
 *                   properties:
 *                     _id:
 *                       type: string
 *                       example: "64b77f5c9fae2b6a0cc21b80"
 *                     name:
 *                       type: string
 *                       example: "John Doe"
 *                     mobileNumber:
 *                       type: string
 *                       example: "9876543210"
 *                     email:
 *                       type: string
 *                       example: "john@example.com"
 *                     role:
 *                       type: string
 *                       example: "patient"
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       404:
 *         description: User not found
 *       500:
 *         description: Failed to fetch user
 */

            
router.get(
  '/user',
  authMiddleware,
  getAuthUserController
);

/**
 * @swagger
 * /api/auth/logout:
 *   post:
 *     tags:
 *       - Authentication
 *     summary: Logout user
 *     description: Logs out the user by blacklisting the JWT token.
 *     security:
 *       - bearerAuth: []  # Requires JWT token in Authorization header
 *     responses:
 *       200:
 *         description: Logout successful. Token blacklisted.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Logout successful. Token blacklisted.
 *       401:
 *         description: Unauthorized - Invalid or missing token
 *       500:
 *         description: Logout failed due to internal error
 */

router.post(
  '/logout',
  authMiddleware,
  logoutController
);


/**
 * @swagger
 * /api/auth/user:
 *   put:
 *     tags:
 *       - Authentication
 *     summary: Update authenticated user's profile
 *     description: Allows an authenticated user to update their profile and role-based details.
 *     security:
 *       - bearerAuth: []  # Requires JWT token
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: "John Doe"
 *               email:
 *                 type: string
 *                 example: "john@example.com"
 *               gender:
 *                 type: string
 *                 enum: [male, female, other]
 *                 example: "male"
 *               dateOfBirth:
 *                 type: string
 *                 format: date
 *                 example: "1990-01-01"
 *               photo:
 *                 type: string
 *                 example: "https://example.com/photo.jpg"
 *               doctorInfo:
 *                 type: object
 *                 properties:
 *                   specialization:
 *                     type: string
 *                   education:
 *                     type: string
 *                   experience:
 *                     type: string
 *                   licenseNumber:
 *                     type: string
 *                   bio:
 *                     type: string
 *               patientInfo:
 *                 type: object
 *                 properties:
 *                   bloodGroup:
 *                     type: string
 *                     example: "B+"
 *                   allergies:
 *                     type: array
 *                     items:
 *                       type: string
 *                   medicalHistory:
 *                     type: array
 *                     items:
 *                       type: string
 *     responses:
 *       200:
 *         description: User updated successfully
 *       401:
 *         description: Unauthorized
 *       404:
 *         description: User not found
 *       500:
 *         description: Failed to update user profile
 */

router.put('/user', authMiddleware, updateAuthUserController);


module.exports = router;